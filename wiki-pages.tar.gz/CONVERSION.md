# mw2wm conversion report

Total unhandled constructs: **105**

## Summary

| Kind | Count |
|---|---:|
| `lua-invoke` | 74 |
| `unknown-tag` | 17 |
| `file-option-dropped` | 10 |
| `multiple-defaults` | 3 |
| `special-link` | 1 |

## `file-option-dropped` (10)

| Detail | Page | Count |
|---|---|---:|
| `link={{{imagelink|}}}` | `Template / Caution` | 4 |
| `link=` | `Template / Dagger` | 1 |
| `link=` | `Template / Documentation_subpage` | 1 |
| `link=` | `Template / Increase` | 1 |
| `link=` | `Template / Intricate_template` | 1 |
| `class=noviewer` | `Template / Sister_project` | 1 |
| `link=` | `Template / Sister_project` | 1 |

## `lua-invoke` (74)

| Detail | Page | Count |
|---|---|---:|
| `check isxn` | `Template / ISBN` | 9 |
| `InfoboxImage` | `Template / Infobox_settlement` | 8 |
| `InfoboxImage` | `Template / Infobox_country` | 6 |
| `infobox` | `Template / Infobox_officeholder∕office` | 2 |
| `Math` | `Template / Round` | 2 |
| `String` | `Template / Sandbox_other` | 2 |
| `citation/CS1` | `Template / Cite_book` | 1 |
| `citation/CS1` | `Template / Cite_web` | 1 |
| `Coordinates` | `Template / Coord` | 1 |
| `Check for unknown parameters` | `Template / Coord` | 1 |
| `Check for unknown parameters` | `Template / Div_col` | 1 |
| `documentation` | `Template / Documentation` | 1 |
| `documentation` | `Template / Documentation∕en` | 1 |
| `Template translation` | `Template / Documentation∕en` | 1 |
| `Error` | `Template / Error-small` | 1 |
| `Hatnote` | `Template / Hatnote` | 1 |
| `High-use` | `Template / High-use` | 1 |
| `String` | `Template / High-use∕num` | 1 |
| `Icon` | `Template / Icon` | 1 |
| `Infobox` | `Template / Infobox` | 1 |
| `Country extract` | `Template / Infobox_country` | 1 |
| `Check for unknown parameters` | `Template / Infobox_country` | 1 |
| `infobox` | `Template / Infobox_officeholder` | 1 |
| `Check for unknown parameters` | `Template / Infobox_officeholder` | 1 |
| `person height` | `Template / Infobox_person∕height` | 1 |
| `Coordinates` | `Template / Infobox_settlement` | 1 |
| `Check for unknown parameters` | `Template / Infobox_settlement` | 1 |
| `Page` | `Template / IsValidPageName` | 1 |
| `Italic title` | `Template / Italic_title` | 1 |
| `lang` | `Template / Lang-fr` | 1 |
| `lang` | `Template / Lang-la` | 1 |
| `lang` | `Template / Lang-mia` | 1 |
| `lang` | `Template / Lang` | 1 |
| `Location map` | `Template / Location_map` | 1 |
| `Lua banner` | `Template / Lua` | 1 |
| `Math` | `Template / Max` | 1 |
| `Message box` | `Template / Mbox` | 1 |
| `Template translation` | `Template / Navbar` | 1 |
| `Template translation` | `Template / Navbar∕en` | 1 |
| `Navbox` | `Template / Navbox` | 1 |
| `Message box` | `Template / Ombox` | 1 |
| `Parameter names example` | `Template / Parameter_names_example` | 1 |
| `Math` | `Template / Precision` | 1 |
| `Check for unknown parameters` | `Template / Reflist` | 1 |
| `Section link` | `Template / Section_link` | 1 |
| `Side box` | `Template / Side_box` | 1 |
| `String` | `Template / Str_endswith` | 1 |
| `String` | `Template / Translatable` | 1 |
| `URL` | `Template / URL` | 1 |
| `Uses Wikidata` | `Template / Uses_Wikidata` | 1 |
| `YMD to ISO` | `Template / YMD_to_ISO` | 1 |

## `multiple-defaults` (3)

| Detail | Page | Count |
|---|---|---:|
| `largest_settlement_type: 'largest city' vs 'city'` | `Template / Infobox_country` | 1 |
| `1: 'a' vs 'b'` | `Template / Str_endswith` | 1 |
| `2: 'a' vs 'b'` | `Template / Str_endswith` | 1 |

## `special-link` (1)

| Detail | Page | Count |
|---|---|---:|
| `Special:MyLanguage/{{{1}}}` | `Template / Localized_link` | 1 |

## `unknown-tag` (17)

| Detail | Page | Count |
|---|---|---:|
| `table` | `Giovoria_Names` | 2 |
| `table` | `Kerbal_Exploration_Association` | 2 |
| `section` | `Template / Column-generating_template_families` | 2 |
| `table` | `Imperial_Fleet_of_Arthagog` | 1 |
| `table` | `Military_Council` | 1 |
| `table` | `Template / CSS3_multiple_column_layout` | 1 |
| `table` | `Template / Column-generating_template_families` | 1 |
| `table` | `Template / Correct_title_examples` | 1 |
| `table` | `Template / Infobox_settlement∕columns` | 1 |
| `table` | `Template / Infobox_settlement∕doc` | 1 |
| `translate` | `Template / Navbar` | 1 |
| `templatestyles` | `Template / Refbegin` | 1 |
| `tr` | `Template / Shared_Template_Warning` | 1 |
| `templatestyles` | `Template / TOC_limit` | 1 |

